package com.pingpong.app;

public class ConfigConstants
{
  public final static String COMMAND_KEY            = "command";
  
  // commands COMMAND_TASKS
  public final static String COMMAND_LOGIN    = "login";
  public final static String COMMAND_COACH    = "coach";
  public final static String COMMAND_SEARCHCOACH    = "searchcoach";
  public final static String COMMAND_BACKLOGIN    = "backlogin";
  public final static String COMMAND_TASKS    = "tasks";
  public final static String COMMAND_MEMBERINFO         = "memberinfo";
  public final static String COMMAND_REQINFO            = "reqinfo";
  public final static String COMMAND_RESULTS = "result";
  public final static String COMMAND_STATUS = "status";
  public final static String COMMAND_UPDATESTATUS = "updatestatus";
  public final static String COMMAND_UPDATE = "update";
  public final static String COMMAND_TARGET         = "target";
  public final static String COMMAND_APPSERVER      = "appserver";
  public final static String COMMAND_SEARCH        = "search";
  public final static String COMMAND_FINDPWD        = "findpwd";
  public final static String COMMAND_CONFIRM        = "confirm";
  public final static String COMMAND_SCHEDULE        = "schedule";
  public final static String LOGFILE        = "c:\\myproject\\log.txt";
}