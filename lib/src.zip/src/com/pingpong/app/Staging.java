package com.pingpong.app;

import java.io.FileNotFoundException;
import java.io.IOException;


import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Vector;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.SendFailedException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.oreilly.servlet.MultipartResponse;
import com.oreilly.servlet.ServletUtils;



public class Staging extends HttpServlet {
  public boolean test = true;
  public String emailError = "No";
  private HttpSession session;
  public static int pwdValid=0;
  private static Map<String, String> map= new HashMap<String, String>(100);

  
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    doGet(request, response);
  }
  
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	//this is the mapping info. It will be eliminated in the future.
   /* map.put("location1", "Concord");
    map.put("location2", "Alameda");
    map.put("location3", "ICC");
    map.put("location4", "PingPongDojo");
    map.put("location5", "TopSpin");
    map.put("location6", "PaloAlto");
    map.put("location7", "Berkeley");
    map.put("location8", "SFTTC");
    map.put("location9", "CTTA");
    map.put("location10", "SVTTC");
    map.put("location11", "TriValley");
   
    map.put("location12", "WSATT");
    map.put("location13", "FosterCity");
    map.put("location14", "SFCTTC");*/
	  
	session = request.getSession();
	  
    pwdValid=0;
    try {
     
      String command = (String)request.getParameter(ConfigConstants.COMMAND_KEY);
      if (command == null || command.trim().length() == 0)
        throw new ConfigException ("Invalid request command.", true);
        
    /*  if (!command.equals(ConfigConstants.COMMAND_APPLICATION))
      {
        boolean validSession = ConfigHelper.validateSession(request);
        if (!validSession)
          throw new ConfigException("Invalid session. ", true);
      }*/
      //test a connection first because of a mysql bug.
      Connection con = getConnectTionFromPool();
	  String teststmt = "select * from login";
	  ConfigLogUtil.log(ConfigConstants.LOGFILE, "calling from doGet for testing purpose.");
	  executeQueryStmt(con, teststmt);
	  
	  try {
		  Connection con1;
		  while (!test){
			  con1 = getConnectTionFromPool();  
			  ConfigLogUtil.log(ConfigConstants.LOGFILE, "calling from doGet.");
			  executeQueryStmt(con1, teststmt);
			  try {
				  con1.close();
			  }catch (Exception m){
				  ConfigLogUtil.log(ConfigConstants.LOGFILE, m.getMessage()); 
			  }
		  
		  }
		  con.close();
		  
	  }catch(Exception n){
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, n.getMessage());
		  
	  }
	  
	  // test done

      if (command.equals(ConfigConstants.COMMAND_LOGIN))
        doLogin(request, response);
      if (command.equals(ConfigConstants.COMMAND_BACKLOGIN))
          doBackLogin(request, response);
      if (command.equals(ConfigConstants.COMMAND_MEMBERINFO))
    	 doMemberInfo(request, response);
      if (command.equals(ConfigConstants.COMMAND_REQINFO))
     	 doSelectMember(request, response);
      if (command.equals(ConfigConstants.COMMAND_RESULTS))
    	  doSendEmail(request, response);
      if (command.equals(ConfigConstants.COMMAND_STATUS))
    	  doStatus(request, response);
      if (command.equals(ConfigConstants.COMMAND_UPDATESTATUS))
    	  doStatusUpdate(request, response);
      if (command.equals(ConfigConstants.COMMAND_TASKS))
    	  doSelectTask(request, response);
      if (command.equals(ConfigConstants.COMMAND_UPDATE))
    	  doMemberUpdate(request, response);
      if (command.equals(ConfigConstants.COMMAND_FINDPWD))
    	  doFindPwd(request, response);
      if (command.equals(ConfigConstants.COMMAND_SCHEDULE))
    	  doSchedule(request, response);
      if (command.equals(ConfigConstants.COMMAND_SEARCH))
    	  doSearchSchedule(request, response);
      if (command.equals(ConfigConstants.COMMAND_SEARCHCOACH))
    	  doSelectCoach(request, response);
      if (command.equals(ConfigConstants.COMMAND_COACH))
    	  doContactCoach(request, response);
      
        
    } catch (ConfigException ce)
    {
      ce.printStackTrace();
      ErrorBean errorBean = new ErrorBean();
      errorBean.seterrormsg(ce.getMessage());
      errorBean.setrequirelogin(ce.getRequireLogin());
      if (session != null)
        session.setAttribute("errorBean", errorBean);
      request.getRequestDispatcher("error.jsp").forward(request, response);     
    } catch (Exception e)
    {
      e.printStackTrace();
      ErrorBean errorBean = new ErrorBean();
      errorBean.seterrormsg("Internal server error.");
      errorBean.setdetailmsg(e.toString());
      errorBean.setrequirelogin(true);
      if (session != null)
        session.setAttribute("errorBean", errorBean);
      request.getRequestDispatcher("error.jsp").forward(request, response);     
    }
  }
  
  private void doSearchSchedule(HttpServletRequest request, HttpServletResponse response){
	  try{
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "search schedule");
		  String back = (String)request.getParameter("back");
		  if (back!=null && back.equals("back")){
			  request.getRequestDispatcher("tasks.jsp").forward(request, response);
			  return;
		  }
		 
		 
		  String expectLow = (String) request.getParameter("expectlow");
		  String expectHigh = (String) request.getParameter("expecthigh");
		  if (expectLow.equals("none"))
			  expectLow="0";
		  
		  if (expectHigh.equals("none"))
			  expectHigh="2601";
		  
		
		 
		  String Email = (String)session.getAttribute("sessionMail");
		
		  String Location="";
		//  String[] raterange = expectRate.split("-");
		  String lowrate = expectLow;
		  String highrate = expectHigh;
		  String lastname = (String)request.getParameter("lastname");
		  if (lastname  == null)
			  lastname = "";
		  lastname.toLowerCase();
		
		  
		  String state = (String)request.getParameter("state");
		  if (state==null)
			  state="";
		  state.toUpperCase();
		  
		  String country = (String)request.getParameter("country");
		  if (country==null)
			  country="";
		  country.toUpperCase();
		  
		  
		
		  Location = (String)request.getParameter("club");
		  String stmt2 = "select Username, Lowrate, Highrate, date, day, time, frequency from ppmembers, schedules where ppmembers.Email=schedules.email and ppmembers.Lowrate >"+"'"+lowrate+"'"+" and ppmembers.Highrate <"+"'"+highrate+"'"+" and ppmembers.Username like '%"+lastname+"'"+" and schedules.club like "+"'%"+Location+"%'"+" and schedules.state="+"'"+state+"'";
			ConfigLogUtil.log(ConfigConstants.LOGFILE, stmt2);
			Connection con = getConnectTionFromPool();
			ResultSet rs2 = executeQueryStmt(con, stmt2);
			//con.close();
			request.setAttribute("tempcon", con);
			
			request.setAttribute("schedule", rs2);
			session.setAttribute("sessionClub", Location);
			request.getRequestDispatcher("scheduletable.jsp").forward(request, response);
	  }catch(Exception n){
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, n.getMessage());
		  
	  }
		
		 
	  
	  
	  
  }
  
  private void doMemberUpdate(HttpServletRequest request, HttpServletResponse response){
	  Vector rates=new Vector();
	  String[] temp;
	  
	  try{
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "In the doMemberUpdate method.");
		  String back = (String)request.getParameter("back");
		  if (back!=null && back.equals("back")){
			  request.getRequestDispatcher("tasks.jsp").forward(request, response);
			  return;
		  }
		  //should be session mail
		  String Email = (String)session.getAttribute("sessionMail");
		  String email = (String)request.getParameter("email");
		  if (!Email.equals(email)){
			  request.setAttribute("mailError", "Yes");
			  request.getRequestDispatcher("memberinfo.jsp").forward(request, response);
			  return;
			  
		  }
		  request.setAttribute("mailError", "No");
		  Connection con = getConnectTionFromPool();
		  //Delete old profile.
		  String stmt1 = "delete from login where Email="+"'"+Email+"'";
		  String stmt2 = "delete from ppmembers where Email="+"'"+Email+"'";
		  executeStmt(con, stmt1);
		  executeStmt(con, stmt2);
		  
		  String lastName= (String)request.getParameter("lname");
		  String firstName= (String)request.getParameter("fname");
		  String teamname = (String)request.getParameter("teamname");
		  String coach = (String)request.getParameter("coach");
		  String level = (String)request.getParameter("certified");
		  if (teamname == null)
			  teamname="";
		  teamname.toUpperCase();
		  String state= (String)request.getParameter("state");
		  //state.toUpperCase();
		  String country = (String)request.getParameter("country");
		 // country.toUpperCase();
		  String city = (String)request.getParameter("city");
		  if (city == null)
			  city="";
		  city.toUpperCase();
		  String userName= firstName + " " + lastName;
		  userName = userName.toLowerCase();
		 
		  
		 
		  
		  String pwd = (String)request.getParameter("pwd");
		  String rpwd = (String)request.getParameter("rpwd");
		  String pwderror = "No";
		  if (!pwd.equals(rpwd)){
			  
			  request.setAttribute("pwdError", "Yes");
			  request.getRequestDispatcher("memberinfo.jsp").forward(request, response);
			  return;
		  }  
		  String leagueRate = (String) request.getParameter("leaguerate");
		  
		  if (leagueRate.contains("-")){
			
			  temp=leagueRate.split("-");
			  rates.add(temp[0]);
			  rates.add(temp[1]);
		  }else{
			  leagueRate="";
		  }
		  
		  String usTTRate = (String)request.getParameter("usttrate");
		  if (usTTRate.contains("-")){
		
			  temp=usTTRate.split("-");
			  rates.add(temp[0]);
			  rates.add(temp[1]);
		  }else{
			  usTTRate="";
		  }
	
		  //if not any
		  String estimateRate = (String)request.getParameter("estimaterate");
		  if (estimateRate.contains("-")){
			
			  temp=estimateRate.split("-");
			  rates.add(temp[0]);
			  rates.add(temp[1]);
		  }else{
			  estimateRate="";
		  }
		  
		  if (rates.size()<1){
			  rates.add("0");
			  rates.add("0");
		  }
		  
		  Collections.sort(rates);
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "lowrate= "+rates.get(0));
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "highrate= "+rates.get(rates.size()-1));
		  
		 
		  String playStyle = (String)request.getParameter("playstyle");
		  if (playStyle.contains("any"))
			  playStyle = "any";
		  String rubberType = (String)request.getParameter("rubbertype");
		  if (rubberType.contains("any"))
			  rubberType = "any";
		  String racketStyle = (String)request.getParameter("racketholdstyle");
		  if (racketStyle.contains("any"))
			  racketStyle = "any";
		 
		  /*String Location="";
		  String Space=" ";
		  for (int i=1; i<15; i++){
			  String loc = (String)request.getParameter("location"+i);
			 if (!Location.equals(""))
				 Location=Location + Space;
			 if (loc!=null && loc.equals("on"))
				 Location = Location + map.get("location"+i);
		  }*/
		  String Location=(String)request.getParameter("club");
		
			
		  
		/*  String stmt3 = "insert into ppmembers values ("+"'"+userName+"', "+"'"+email+"', "+
		  "'"+racketStyle+"', "+"'"+rubberType+"', "+"'"+playStyle+"', "+"'"+Location+"', "+Integer.parseInt(rates.get(0).toString())+", "
		  +Integer.parseInt(rates.get(rates.size()-1).toString())+", "+"'"+teamname+"'"+", ''"+")";*/
		  
		  String stmt3 = "insert into ppmembers values ("+"'"+userName+"', "+"'"+email+"', "+
		  "'"+racketStyle+"', "+"'"+rubberType+"', "+"'"+playStyle+"', "+"'"+Location+"', "+Integer.parseInt(rates.get(0).toString())+", "
		  +Integer.parseInt(rates.get(rates.size()-1).toString())+", "+"'"+teamname+"'"+", ''"+", '"+usTTRate+"',"+" '"+leagueRate+"',"+" '"+estimateRate+"'"+", '"+city+"', '"+state+"'"+", '"+country+"'"+", '"+coach+"',"+" '"+level+"'"    +")";
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, stmt3);
		  
		  boolean f1 = false;
		  boolean f2 = false;
		  f1=executeStmt(con, stmt3);
		  String stmt4 = "insert into login values ("+"'"+email+"', "+"'"+pwd+"')";
		  f2=executeStmt(con, stmt4);
		  String keyError = "YES";
		  if (f1 && f2)
			  keyError="NO";
			  
		  con.close();
		  if (keyError.equals("YES")){
			  
			  request.setAttribute("keyError", "Yes");
			  request.getRequestDispatcher("update.jsp").forward(request, response);
			  return;
		  } 
		  
		  String message = "Your profile has been updated.";
		  request.setAttribute("ConfirmMessage", message);
		  request.getRequestDispatcher("confirm.jsp").forward(request, response);
		  
		  
		  
	  }catch(Exception e){
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "got exception in doMemberUpdate method.");
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, e.getMessage());
	  }
	  
	  
  }
  private void doSelectTask(HttpServletRequest request, HttpServletResponse response){
	  try {
		    ConfigLogUtil.log(ConfigConstants.LOGFILE, "In doSelectTask method.");
		  	String back = (String)request.getParameter("back");
		  	if (back!=null && back.equals("back")){
		  		request.getRequestDispatcher("partner.jsp").forward(request, response);
			  return;
		  	}
		  	String task = (String)request.getParameter("task");
	  
		  if (task.equals("up")){
			  
			  Connection con1 = getConnectTionFromPool();
			  String data = "select * from ppmembers where Email="+"'"+(String)session.getAttribute("sessionMail")+"'";
			  ResultSet profile = executeQueryStmt(con1, data);
			 
			  request.setAttribute("profile", profile);
			  request.setAttribute("con1", con1);
			  
			  
			  request.getRequestDispatcher("update.jsp").forward(request, response);
			  return;
		  }
	 
		  if (task.equals("fp")){
			  request.getRequestDispatcher("setrequirementinfo.jsp").forward(request, response);
			  return; 
		  }
		  if (task.equals("fc")){
			  request.getRequestDispatcher("coachsearching.jsp").forward(request, response);
			  return; 
		  }
		  if (task.equals("pt")){
			  request.getRequestDispatcher("schedule.jsp").forward(request, response);
			  return; 
		  }
		  if (task.equals("ck")){
			  request.getRequestDispatcher("searchposting.jsp").forward(request, response);
			  return;
		  }
		  if (task.equals("ca")){
			  String Email = (String)session.getAttribute("sessionMail");
			  Connection con2 = getConnectTionFromPool();
			  //Delete old profile.
			  String stmt1 = "delete from login where Email="+"'"+Email+"'";
			  String stmt2 = "delete from ppmembers where Email="+"'"+Email+"'";
			  executeStmt(con2, stmt1);
			  executeStmt(con2, stmt2);
			  con2.close();
			  request.getRequestDispatcher("cancel.html").forward(request, response);
			  return;
		  }
		  if (task.equals("ue")){
			  String id = (String)request.getParameter("eid");
			 // String Location = (String)request.getParameter("Location");
			  String Id = id;
			  String Email = (String)session.getAttribute("sessionMail");
			  
			  
			  
			  Connection con = getConnectTionFromPool();
			  
			  
			  String st1 ="select Email from ppmembers a, event b where b.InvitedBy=a.Username and b.Id="+Id;
			  ResultSet ems = executeQueryStmt(con, st1);
			  String em=null;
			  while(ems.next())
				  em = ems.getString(1);
			  String flag="";
			  if (em==null || !em.equals(Email)){
				  
				  request.setAttribute("flag", "error");
				  request.getRequestDispatcher("tasks.jsp").forward(request, response);
			  }
			  request.setAttribute("myMail", Email);
			  request.setAttribute("inviMail", em);
			  
			
				
			  String stmt1= "select b.Username, c.Email, c.Status, a.Time, a.Location from event a, ppmembers b, person c where c.Email=b.Email and a.Id="+Id+" and c.Id="+Id;
			  ConfigLogUtil.log(ConfigConstants.LOGFILE, stmt1);
			
				  ResultSet srs = executeQueryStmt(con, stmt1);
				  
				  String stmt2="select Status from event where Id="+Id;
			      ResultSet event = executeQueryStmt(con, stmt2);
			      
				  request.setAttribute("srs", srs);
				  request.setAttribute("event", event);
				  request.setAttribute("con", con);
				  request.setAttribute("myMail", Email); 
				  
				  session.setAttribute("sessionMail", Email);
				  session.setAttribute("id", Id);
				 // request.setAttribute("Location", Location);
				  request.getRequestDispatcher("status.jsp").forward(request, response);
			  
		  
		  }
	  
	  } catch (Exception e){
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "In doSelectTask method.");
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, e.getMessage());
		  
	  }
	  
  }
  
  private void doStatus(HttpServletRequest request, HttpServletResponse response){
	  
	  
	 
	  
	  
	  String Location = (String)request.getParameter("Location");
	  if (Location.contains("Any"))
		  Location = "undecided location";
	  String Id = (String)request.getParameter("Id");
	  String Email = (String)request.getParameter("Email");
	  ConfigLogUtil.log(ConfigConstants.LOGFILE, "Get a db connection");
	  Connection con = getConnectTionFromPool();
	  ConfigLogUtil.log(ConfigConstants.LOGFILE, "Got the db connection.");
		
		
	  String stmt1= "select b.Username, c.Email, c.Status, a.Time, a.Location, b.Lowrate, b.Highrate from event a, ppmembers b, person c where c.Email=b.Email and a.Id="+Id+" and c.Id="+Id;
	  ConfigLogUtil.log(ConfigConstants.LOGFILE, stmt1);
	  try {
		  ResultSet srs = executeQueryStmt(con, stmt1);
		  String stmt2="select Status from event where Id="+Id;
	      ResultSet event = executeQueryStmt(con, stmt2);
	      //get inviter email
	 	 String st1 ="select Email, Username from ppmembers a, event b where b.InvitedBy=a.Username and b.Id="+Id;
		 ResultSet ems = executeQueryStmt(con, st1);
		 String em=null;
		 String inviter = null;
		 while(ems.next()){
			  em = ems.getString(1);
			  inviter = ems.getString(2);
		 }
		 
		  request.setAttribute("event", event);
	  
		  request.setAttribute("srs", srs);
		  request.setAttribute("con", con);
		  request.setAttribute("myMail", Email);
		  request.setAttribute("inviMail", em);
		  request.setAttribute("inviter", inviter);
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "myMail="+Email+" inviMail="+em);
		  session.setAttribute("sessionMail", Email);
		  
		  session.setAttribute("id", Id);
		  request.setAttribute("Location", Location);
		  request.getRequestDispatcher("status.jsp").forward(request, response);
	  }catch (Exception e){
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, e.getMessage());
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "I am there.");
	  }
	//select Username, Status from events a, ppmembers b where a.Email=b.Email and a.Id=30387114987898;
  }
  
  
  private void doSendEmail(HttpServletRequest request, HttpServletResponse response){
	  
	      //date, location and message
	  //String expectRate = (String) request.getParameter("expectrate");
	  //Get the playtime here.
	  //Parse it to a date string
	  //set it in the session.
	  //do same thing for comment.
	  try {
	  String back = (String)request.getParameter("back");
	  if (back!=null && back.equals("back")){
		 
		  request.getRequestDispatcher("setrequirementinfo.jsp").forward(request, response);
		  return;
	  }
	  //String pnumber = (String) request.getParameter("pnumber");
	  String day = (String) request.getParameter("Day");
	  ConfigLogUtil.log(ConfigConstants.LOGFILE, "I am here0");
	  String month = (String)request.getParameter("Month");
	  String year = (String)request.getParameter("Year");
	  String time = (String)request.getParameter("Time");
	  ConfigLogUtil.log(ConfigConstants.LOGFILE, "I am here1");
	  ConfigLogUtil.log(ConfigConstants.LOGFILE, year + " " + month + " " + day + " " + time);
	  String realtime = "";
	  int clock;
	  String[] temptime=null;
	  String[] tmp = null;
	  if (time.contains("AM")){
		  temptime = time.split("AM");
		  
	  	  realtime = temptime[0];
	  }else{
		  temptime = time.split("PM") ;
		  if (temptime[0].contains(":")){
			  tmp = temptime[0].split(":");
			  clock = Integer.parseInt(tmp[0]);
			  clock = clock + 12;
			  realtime = Integer.toString(clock)+":30";
		  }else{
			  
			  clock = Integer.parseInt(temptime[0]);
			  clock = clock + 12;
			  realtime = Integer.toString(clock);
		  }
		  
	  }
	  ConfigLogUtil.log(ConfigConstants.LOGFILE, "here2");
	  String date="";
	  if (realtime.contains(":")){
		  date = year + "-" + month + "-" + day + " " + realtime + ":00";
	  }else{
		  date = year + "-" + month + "-" + day + " " + realtime + ":00:00";
	  }
	  ConfigLogUtil.log(ConfigConstants.LOGFILE, date);
	  
	  //String Message = (String) request.getParameter("Message");
	  //ConfigLogUtil.log(ConfigConstants.LOGFILE, Message);
	  
		  
		 
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "got email list");
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, (String)(request.getParameter("rowsize")));
		  
		  long id=System.nanoTime();
		
		  String location = (String)request.getParameter("club");
		  if (location!=null && location != ""){
			  
		  }else{
			  location = "undecided place";
		  }
		  String sMail = (String)session.getAttribute("sessionMail");
		  String invitedby = (String)session.getAttribute("sessionName");
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "my session mail "+sMail);
		  //get time, day, month, year from session
		  Connection con = getConnectTionFromPool();
		  boolean flag = false;
		  String message2 = "";
		  boolean rowSelected = false;
		  String message0 = "Don't email the following first link to someone else because it is your private link.\n\n";
		 
		  
		 // String[] emails = new String[100];
		 // int j=0;

		  
		  String stmt2 = "insert into event values ("+"'"+id+"', "+"'"+"active"+"', "+"'"+date+"', "+"'"+invitedby+"', "+"'"+location+"')";
		  //String stmt3 = "insert into person values ("+"'"+email+"', "+"'"+initStatus+"', "+"'"+id+"')";
		  executeStmt(con, stmt2);
		  for (int i=1; i<=Integer.parseInt((request.getParameter("rowsize"))); i++ ){
			  
			  String email = (String)request.getParameter("name"+i);
			  if (email != null && email !=""){
				  String initStatus = "unknown";
				  rowSelected = true;
				  //check session mail
				  if (email.equals(sMail)){
					  flag = true;
					  initStatus = "come";
					  
					  message2 = "Your invitation has been sent. Please click and bookmark the first link below. You can check or update the status through this link.\n\n";
				  }else{
					 
					  message2 = "Someone is inviting you to play. Please click and bookmark the first link below. You can check or update the status through this link.\n\n";
				  }
				  //need check a login email.
				 // String stmt2 = "insert into event values ("+"'"+id+"', "+"'"+time+"', "+"'"+invitedby+"', "+"'"+location+"')";
				  String stmt3 = "insert into person values ("+"'"+id+"', "+"'"+email+"', "+"'"+initStatus+"')";
				 // executeStmt(con, stmt2);
				  executeStmt(con, stmt3);
				  ConfigLogUtil.log(ConfigConstants.LOGFILE, stmt2);
				  ConfigLogUtil.log(ConfigConstants.LOGFILE, "MailAddress= "+email);
				  //set up message variable
				  String message1 = "Playing ping pong is fun. \n\n";
				  
				  String message3="http://www.pingpongmatch.com/staging/Mystuff?command=status&Email="+email+"&Id="+id+"&Location="+location;
				  String message4="Use the read-only link below to share this event with friends.\n";
				  String message5="http://www.pingpongmatch.com/staging/Mystuff?command=status&Email="+"dummy"+"&Id="+id+"&Location="+location;
				  String message6="  Have a great match!";
				  
				  String message = message2  + message3 + "\n\n"  + "\n" + message4 + message5 + "\n\n"+message6;
				  ConfigLogUtil.log(ConfigConstants.LOGFILE, message);
				  
				  //message=general message + timestamp;url;email;event id;location
				  //adding to email list
				  //emails[j]= email;
				  String event="on "+date+" id="+id;
				  sendMail(message, email, event);
				//  ConfigLogUtil.log(ConfigConstants.LOGFILE, emails[j]);
				  
				 
				  
			  }
			  
			  
		  }
		  request.setAttribute("selectError", "No");
		  if (!rowSelected){
			  request.setAttribute("selectError", "Yes");
			  request.getRequestDispatcher("setrequirementinfo.jsp").forward(request, response);
			  return;
			  
		  }
		  request.setAttribute("selectError", "No");
		  
		  if (!flag){
			  String email = sMail;
			  String initStatus = "come";
			  String stmt3 = "insert into person values ("+"'"+id+"', "+"'"+email+"', "+"'"+initStatus+"')";
			  //String stmt2 = "insert into events values ("+"'"+id+"', "+"'"+email+"', "+"'"+initStatus+"')";
			  //String stmt2 = "insert into events values ("+"'"+id+"', "+"'"+email+"', "+"'"+initStatus+"', "+"'"+time+"')";
			  executeStmt(con, stmt3);
			  ConfigLogUtil.log(ConfigConstants.LOGFILE, stmt2);
			  ConfigLogUtil.log(ConfigConstants.LOGFILE, "MailAddress= "+email);
			  //set up message variable
			  String message1 = "Playing ping pong is fun. \n\n";
			  message2 = "Your invitation has been sent. Please click and bookmark the first link below. You can check or update the status through this link.\n\n";
			  
			  String message3="http://www.pingpongmatch.com/staging/Mystuff?command=status&Email="+email+"&Id="+id+"&Location="+location;
			  String message4="Read-Only link for your friend who is interested in the event.\n";
			  String message5="http://www.pingpongmatch.com/staging/Mystuff?command=status&Email="+"dummy"+"&Id="+id+"&Location="+location;
			  String Mymessage = message2 + message3 +"\n\n"+ message4 + message5;
			  ConfigLogUtil.log(ConfigConstants.LOGFILE, Mymessage);
			 
			  
		//	  ConfigLogUtil.log(ConfigConstants.LOGFILE, "own="+myemail[0]);
			  String event="on "+date;
			  sendMail(Mymessage, email, event);
		  }
		  
		  con.close();

		  String message = "Your invitation has been sent.";
		  request.setAttribute("ConfirmMessage", message);
		  request.getRequestDispatcher("confirm.jsp").forward(request, response);
		 
	  }catch(Exception f){
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, f.getMessage());
	  }
  }
  
  private void doSelectMember(HttpServletRequest request, HttpServletResponse response){
	  try{
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "select members");
		  String back = (String)request.getParameter("back");
		  if (back!=null && back.equals("back")){
			  request.getRequestDispatcher("tasks.jsp").forward(request, response);
			  return;
		  }
		 
		 
		  String expectLow = (String) request.getParameter("expectlow");
		  String expectHigh = (String) request.getParameter("expecthigh");
		  if (expectLow.equals("none"))
			  expectLow="0";
		  
		  if (expectHigh.equals("none"))
			  expectHigh="2601";
		  
		//  session.setAttribute("DATE", date);
		//  session.setAttribute("MESSAGE", message);
		  
		  //currentday info
		  String today = (String) request.getParameter("today");
		  String cDay = (String) request.getParameter("currentDay");
		  String cMonth = (String) request.getParameter("currentMonth");
		  String cYear = (String) request.getParameter("currentYear");
		  String cDate = cDay + "-" +cMonth+ "-" +cYear;
		 
		  String Email = (String)session.getAttribute("sessionMail");
		  
		  String  playStyle = "";
		  
		  
		  String  rubberType = "";
		  
		  String rackethold = "";
		  String Location="";
		//  String[] raterange = expectRate.split("-");
		  String lowrate = expectLow;
		  String highrate = expectHigh;
		  String lastname = (String)request.getParameter("lastname");
		  if (lastname  == null)
			  lastname = "";
		  lastname.toLowerCase();
		  String teamname = (String)request.getParameter("teamname");
		  if (teamname==null)
			  teamname="";
		  teamname.toUpperCase();
		  
		  String city = (String)request.getParameter("city");
		  if (city==null)
			  city="";
		  city.toUpperCase();
		  
		  String state = (String)request.getParameter("state");
		  if (state==null)
			  state="";
		  state.toUpperCase();
		  
		  String country = (String)request.getParameter("country");
		  if (country==null)
			  country="";
		  country.toUpperCase();
		  
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "lastname="+lastname+" teamname="+teamname+" lowrate="+lowrate+ " highrate="+highrate);
		
		  Location = (String)request.getParameter("club");
		
		  request.setAttribute("myLocations", Location);
		  session.setAttribute("myLocations", Location);
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "play location="+Location);
		  
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "before loop");
		  Connection con = getConnectTionFromPool();
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "I passed getConnection2.");
		  
		  //check one who wants to play today.
		  String stmt1="";
		  if (today != null && today.equals("yes")){
			  
			  stmt1="select * from ppmembers where Lowrate >= "+lowrate+ " and Highrate <= "+highrate+ " and Rubberstyle like '%"+rubberType+"' and Playstyle like '%"+playStyle+"' and Racketstyle like '%"+rackethold+"' and Username like '%"+lastname+"' and TeamName like '%"+teamname+"%'"+ " and City like '%"+city+"%'"+" and State like '%"+state+"%'" +" and Country like '%"+country+"%'" + " and Today='"+cDate+"'"+ " and Email != '"+Email+"'";
			  
			  
			  
		  }else{
			  stmt1="select * from ppmembers where Lowrate >= "+lowrate+ " and Highrate <= "+highrate+ " and Rubberstyle like '%"+rubberType+"' and Playstyle like '%"+playStyle+"' and Racketstyle like '%"+rackethold+"' and Username like '%"+lastname+"' and TeamName like '%"+teamname+"%'"+ " and City like '%"+city+"%'" +" and State like '%"+state+"%'"+" and Country like '%"+country+"%'"+ " and Email != '"+Email+"'";
			  
		  }
		  
			
			
		 
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, stmt1);
		  ResultSet rs = executeQueryStmt(con, stmt1);
		  
		  //set a record for today's play
		  if (today != null && today.equals("yes")){
			  Connection con1 = getConnectTionFromPool();
			  String st = "update ppmembers set Today="+"'"+cDate+"'"+" where Email='"+session.getAttribute("sessionMail")+"'";
			  ConfigLogUtil.log(ConfigConstants.LOGFILE, st);
			  executeStmt(con1, st);
			  con1.close();
		  }
		  
		  session.setAttribute("DBResults", rs); 
		  session.setAttribute("ResultCon", con);
		  session.setAttribute("selectedState", state);
		  request.getRequestDispatcher("results.jsp").forward(request, response);
		
		  //con.close();
		  
	  }catch (Exception a){
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, a.getMessage());  
		  
	  }
	  
  }
  
  private void doSelectCoach(HttpServletRequest request, HttpServletResponse response){
	  try{
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "select members");
		  String back = (String)request.getParameter("back");
		  if (back!=null && back.equals("back")){
			  request.getRequestDispatcher("tasks.jsp").forward(request, response);
			  return;
		  }
		 
		 
		  String expectLow = (String) request.getParameter("expectlow");
		  String expectHigh = (String) request.getParameter("expecthigh");
		  if (expectLow.equals("none"))
			  expectLow="0";
		  
		  if (expectHigh.equals("none"))
			  expectHigh="2601";
		  
		//  session.setAttribute("DATE", date);
		//  session.setAttribute("MESSAGE", message);
		  
		  //currentday info
		  /*String today = (String) request.getParameter("today");
		  String cDay = (String) request.getParameter("currentDay");
		  String cMonth = (String) request.getParameter("currentMonth");
		  String cYear = (String) request.getParameter("currentYear");
		  String cDate = cDay + "-" +cMonth+ "-" +cYear;*/
		 
		  String Email = (String)session.getAttribute("sessionMail");
		  
		  String  playStyle = "";
		  
		  
		  String  rubberType = "";
		  
		  String rackethold = ""; 
		  String Location="";
		//  String[] raterange = expectRate.split("-");
		  String lowrate = expectLow;
		  String highrate = expectHigh;
		  String lastname = (String)request.getParameter("lastname");
		  if (lastname  == null)
			  lastname = "";
		  lastname.toLowerCase();
		String teamname = (String)request.getParameter("teamname");
		  if (teamname==null)
			  teamname="";
		  teamname.toUpperCase();
		  
		  String certified = (String)request.getParameter("certified");
		  if (certified.equals("No"))
			  certified="";
		  certified.toUpperCase();
		  
		  String city = (String)request.getParameter("city");
		  if (city==null)
			  city="";
		  city.toUpperCase();
		  
		  String state = (String)request.getParameter("state");
		  if (state==null)
			  state="";
		  state.toUpperCase();
		  
		  String country = (String)request.getParameter("country");
		  if (country==null)
			  country="";
		  country.toUpperCase();
		  
		 // ConfigLogUtil.log(ConfigConstants.LOGFILE, "lastname="+lastname+" teamname="+teamname+" lowrate="+lowrate+ " highrate="+highrate);
		
		  Location = (String)request.getParameter("club");
		
		  request.setAttribute("CmyLocations", Location);
		  session.setAttribute("CmyLocations", Location);
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "play location="+Location);
		  
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "before loop");
		  Connection con = getConnectTionFromPool();
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "I passed getConnection2.");
		  
		  //check one who wants to play today.
		  String stmt1="";
		 /* if (today != null && today.equals("yes")){
			  
			  stmt1="select * from ppmembers where Lowrate >= "+lowrate+ " and Highrate <= "+highrate+ " and Rubberstyle like '%"+rubberType+"' and Playstyle like '%"+playStyle+"' and Racketstyle like '%"+rackethold+"' and Username like '%"+lastname+"' and TeamName like '%"+teamname+"%'"+ " and City like '%"+city+"%'"+" and State like '%"+state+"%'" +" and Country like '%"+country+"%'" + " and Today='"+cDate+"'"+ " and Email != '"+Email+"'";
			  
			  
			  
		  }else{*/
			  stmt1="select * from ppmembers where Lowrate >= "+lowrate+ " and Highrate <= "+highrate+ " and Rubberstyle like '%"+rubberType+"' and Playstyle like '%"+playStyle+"' and Racketstyle like '%"+rackethold+"' and Username like '%"+lastname+"' and Level like '%"+certified+"%'"+ " and City like '%"+city+"%'" +" and State like '%"+state+"%'"+" and Country like '%"+country+"%'"+ " and Coach = '"+"Yes"+"'";
			  
		 // }
		  
			
			
		 
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, stmt1);
		  ResultSet rs = executeQueryStmt(con, stmt1);
		  
		  //set a record for today's play
		/* if (today != null && today.equals("yes")){
			  Connection con1 = getConnectTionFromPool();
			  String st = "update ppmembers set Today="+"'"+cDate+"'"+" where Email='"+session.getAttribute("sessionMail")+"'";
			  ConfigLogUtil.log(ConfigConstants.LOGFILE, st);
			  executeStmt(con1, st);
			  con1.close();
		  }*/
		  
		  session.setAttribute("CDBResults", rs); 
		  session.setAttribute("CResultCon", con);
		  session.setAttribute("CselectedState", state);
		  request.getRequestDispatcher("coachresults.jsp").forward(request, response);
		
		  //con.close();
		  
	  }catch (Exception a){
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, a.getMessage());  
		  
	  }
	  
  }

  private void doMemberInfo(HttpServletRequest request, HttpServletResponse response){
	  Vector rates=new Vector();
	  String[] temp1;
	  String[] temp2;
	  String[] temp3;
	  try{
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "I am in domemberinfo");
		  String back = (String)request.getParameter("back");
		  if (back!=null && back.equals("back")){
			  request.getRequestDispatcher("partner.jsp").forward(request, response);
			  return;
		  }
		  String coach = (String)request.getParameter("coach");
		  String level = (String)request.getParameter("certified");
		  String lastName= (String)request.getParameter("lname");
		  String firstName= (String)request.getParameter("fname");
		  String teamname = (String)request.getParameter("teamname");
		  String country = (String)request.getParameter("country");
		  String state = (String)request.getParameter("state");
		  if (teamname == null)
			  teamname="";
		  teamname.toUpperCase();
		  String city = (String)request.getParameter("city");
		  if (city == null)
			  city="";
		  city.toUpperCase();
		  //country.toUpperCase();
		  //state.toUpperCase();
		  String userName= firstName + " " + lastName;
		  userName = userName.toLowerCase();
		 // String lastName= (String)request.getParameter("lname");
		 // String firstName= (String)request.getParameter("fname");
		  String email = (String)request.getParameter("email");
		 
		  
		  String pwd = (String)request.getParameter("pwd");
		  String rpwd = (String)request.getParameter("rpwd");
		  String pwderror = "No";
		  if (!pwd.equals(rpwd)){
			  
			  request.setAttribute("pwdError", "Yes");
			  request.getRequestDispatcher("memberinfo.jsp").forward(request, response);
			  return;
		  } 
		  
		  String leagueRate = (String) request.getParameter("leaguerate");
		  
		  if (leagueRate.contains("-")){
			
			  temp1=leagueRate.split("-");
			
			  rates.add(Integer.parseInt(temp1[0]));
			  rates.add(Integer.parseInt(temp1[1]));
		  }else{
			  leagueRate="";
		  }
		  
		  
		  String usTTRate = (String)request.getParameter("usttrate");
		  if (usTTRate.contains("-")){
		
			  temp2=usTTRate.split("-");
			  rates.add(Integer.parseInt(temp2[0]));
			  rates.add(Integer.parseInt(temp2[1]));
		  }else{
			  usTTRate="";
		  }
	
		  //if not any
		  String estimateRate = (String)request.getParameter("estimaterate");
		  if (estimateRate.contains("-")){
			
			  temp3=estimateRate.split("-");
			  rates.add(Integer.parseInt(temp3[0]));
			  rates.add(Integer.parseInt(temp3[1]));
		  }else{
			  estimateRate="";
		  }
		  
		  if (rates.size()<1){
			  rates.add(0);
			  rates.add(0);
		  }
		  
		  Collections.sort(rates);
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "lowrate= "+rates.get(0));
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "highrate= "+rates.get(rates.size()-1));
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "ratesize= "+rates.size());
		  
		 
		  String playStyle = (String)request.getParameter("playstyle");
		  if (playStyle.contains("any"))
			  playStyle = "any";
		  String rubberType = (String)request.getParameter("rubbertype");
		  if (rubberType.contains("any"))
			  rubberType = "any";
		  String racketStyle = (String)request.getParameter("racketholdstyle");
		  if (racketStyle.contains("any"))
			  racketStyle = "any";
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "I am in domemberinfo after getting inputs");
		  
		  String Location=(String)request.getParameter("club");
		  /*e=" ";
		  for (int i=1; i<15; i++){
			  String loc = (String)request.getParameter("location"+i);
			 if (!Location.equals(""))
				 Location=Location + Space;
			 if (loc!=null && loc.equals("on"))
				 Location = Location + map.get("location"+i);
		  }*/
		  
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "before loop");
		  Connection con = getConnectTionFromPool();
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "I passed getConnection2.");
		  
		  
		 	
		  
		  String stmt1 = "insert into ppmembers values ("+"'"+userName+"', "+"'"+email+"', "+
		  "'"+racketStyle+"', "+"'"+rubberType+"', "+"'"+playStyle+"', "+"'"+Location+"', "+Integer.parseInt(rates.get(0).toString())+", "
		  +Integer.parseInt(rates.get(rates.size()-1).toString())+", "+"'"+teamname+"'"+", ''"+", '"+usTTRate+"',"+" '"+leagueRate+"',"+" '"+estimateRate+"'"+", '"+city+"'"+", '"+state+"'"+", '"+country+"'"+", '"+coach+"',"+" '"+level+"'"+")";
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, stmt1);
		  boolean f1 = false;
		  boolean f2 = false;
		  f1=executeStmt(con, stmt1);
		  String stmt2 = "insert into login values ("+"'"+email+"', "+"'"+pwd+"')";
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, stmt2);
		  f2=executeStmt(con, stmt2);

		//  
		  String keyError = "YES";
		  if (f1 && f2){
			  ConfigLogUtil.log(ConfigConstants.LOGFILE, "both return true.");
			  keyError="NO";
			  request.setAttribute("keyError", "No");
		  }
			  
		  con.close();
		  if (keyError.equals("YES")){
			  
			  request.setAttribute("keyError", "Yes");
			  request.getRequestDispatcher("partner.jsp").forward(request, response);
			  return;
		  } 
		  
		  pwdValid=1;
		  String cDay = (String) request.getParameter("currentDay");
			 session.setAttribute("sessionDay", cDay);
			  String cMonth = (String) request.getParameter("currentMonth");
			  session.setAttribute("sessionMonth", cMonth);
			  String cYear = (String) request.getParameter("currentYear");
			  session.setAttribute("sessionYear", cYear);
			  session.setAttribute("sessionMail", email);
			  session.setAttribute("sessionPwd", pwd);
		  
		  String message = "You have signed up successfully.";
		  request.setAttribute("ConfirmMessage", message);
		  String content ="Welcome to PingPongMatch.com!\nYour membership ID is: "+email+"\n"+
		  "Log in (hot link) now to  search and invite the right level of player(s) to play matches with; hone\n"+
		  "your skills and make new friends!  Team leaders can also leverage this tool to initiate and\norganize games/events.\n"+
		  "The more people participate, the more fun we will have.  Look forward to seeing you in the clubs!\n"+
		  "PPM.com team\nGot questions or need help? Please contact us at support@pingpongmatch.com";
		  String title = "Welcome to PingPongMatch.com";
		  sendMail(content, email, title);
		request.getRequestDispatcher("confirm.jsp").forward(request, response);
		  
	  }catch(Exception e){
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "got exception");
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, e.getMessage());
	  }
  }
  
private void doStatusUpdate(HttpServletRequest request, HttpServletResponse response){
	try {
		
		String done = (String)request.getParameter("done");
		if (done != null && done.equals("exit")){
			
			request.getRequestDispatcher("end1.html").forward(request, response);
			return;
		}
		String message = (String)request.getParameter("Message");
		String smail = (String)session.getAttribute("sessionMail");
		
		
		String res = (String)request.getParameter(smail);
		if (res.equals("not respond"))
			res="unknown";
		String value = (String)request.getParameter("task");
		String stat = "";
		
		if (value.equals("ac"))
			stat="active";
		if (value.equals("co"))
			stat="confirm";
		if (value.equals("ca"))
			stat="cancel";
		if (value.equals("do"))
			stat="done";	
		
		//String Location = (String)request.getParameter("Location");
		Connection con = getConnectTionFromPool();
		ConfigLogUtil.log(ConfigConstants.LOGFILE, "get last connections.");
		String id = (String)session.getAttribute("id");
			
		String stmt	= "update event set Status='"+stat+"' where Id='"+id+"'";
		
		ConfigLogUtil.log(ConfigConstants.LOGFILE, stmt); 
		  
		executeStmt(con, stmt);
		  
		String stmt1= "update person set Status='"+res+"' where Email='"+smail+"' and Id='"+id+"'";
			
		ConfigLogUtil.log(ConfigConstants.LOGFILE, stmt1); 
		  
		executeStmt(con, stmt1);
		//send message if status updated.
		String stmt2 = "select Location, Time from event where Id='"+id+"'";
		ResultSet locs = executeQueryStmt(con, stmt2);
		String location="";
		String time="";
		while (locs.next()){
			location = locs.getString(1);
			time = locs.getString(2);
		}
		String stmt3 = "select Email from person where Id='"+id+"'";
		ResultSet ems = executeQueryStmt(con, stmt3);
		String event = "on "+time+ " update alert!";
		while (ems.next()){
			String up = "status updated \n"+message+"\n\n";
			String finish="";
			if (stat.equals("cancel")||stat.equals("done"))
				finish = "This event has been either done or canceled!\n\n";
			
			String link= up + finish + "http://www.pingpongmatch.com/staging/Mystuff?command=status&Email="+ems.getString(1)+"&Id="+id+"&Location="+location;
			
			ConfigLogUtil.log(ConfigConstants.LOGFILE, message+"no space");
			if (!message.substring(message.length()-1).equals(":"))
				sendMail(link, ems.getString(1), event);
		} 
		con.close();
		//ConfigLogUtil.log(ConfigConstants.LOGFILE, b);
	//set the status
		
		ConfigLogUtil.log(ConfigConstants.LOGFILE, smail);
		ConfigLogUtil.log(ConfigConstants.LOGFILE, res);
		String message4 = "Thank you for updating status.";
		request.setAttribute("ConfirmMessage", message4);
		request.getRequestDispatcher("confirm.jsp").forward(request, response);
	}catch(Exception e){
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "exception in updateStatus");
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, e.getMessage());
	  }
	//not implementation yet.
}

private void doContactCoach(HttpServletRequest request, HttpServletResponse response){
	try {
		
		
		String message = (String)request.getParameter("Message");
		String smail = (String)session.getAttribute("sessionMail");
		
		 for (int i=1; i<=Integer.parseInt((request.getParameter("rowsize"))); i++ ){
			  
			  String email = (String)request.getParameter("name"+i);
			  if (email != null && email !=""){
				  
				 // rowSelected = true;
				
				  String event="Looking for a coach";
				  sendMail(message, email, event);
				//  ConfigLogUtil.log(ConfigConstants.LOGFILE, emails[j]);
				  
				 
				  
			  }
			  
			  
		  }
		
		

		
		

		String message4 = "Your selected coach will contact you.";
		request.setAttribute("ConfirmMessage", message4);
		request.getRequestDispatcher("confirm.jsp").forward(request, response);
	}catch(Exception e){
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, "exception in selectCoach");
		  ConfigLogUtil.log(ConfigConstants.LOGFILE, e.getMessage());
	  }
	//not implementation yet.
}

private void doBackLogin(HttpServletRequest request, HttpServletResponse response){
	
	//
	ConfigLogUtil.log(ConfigConstants.LOGFILE, "I am in doBackLogin");
	Connection con = getConnectTionFromPool();
	ConfigLogUtil.log(ConfigConstants.LOGFILE, "I passed getConnection.");
	//String stmt = "select Pwd from login where Email='mymtl@yahoo.com'";
	String stmt=null;
	String pwd="";
	try{
		String loginName = (String)session.getAttribute("sessionMail");
		String loginPwd = (String)session.getAttribute("sessionPwd");
		stmt = "select Pwd from login where Email="+"'"+loginName+"'";
		ResultSet rs = executeQueryStmt(con, stmt);
		while (rs.next())
			pwd = rs.getString(1);
		
	
		
		con.close();
		
		if (pwd!=null && pwd!="" && pwd.equals(loginPwd) ){
			//session.setAttribute("pwd", "yes");
			pwdValid=1;
			session.setAttribute("sessionMail", loginName);
			session.setAttribute("sessionPwd", loginPwd);
			con = getConnectTionFromPool();
			stmt = "select Username, State, Country, Lowrate, Highrate, Locations  from ppmembers where Email="+"'"+loginName+"'";
			rs = executeQueryStmt(con, stmt);
			String username="";
			String state="";
			String nation="";
			String lowrate="";
			String highrate="";
			String location="";
			while (rs.next()){
				username = rs.getString(1);
				state=rs.getString(2);
				nation=rs.getString(3);
				lowrate=rs.getString(4);
				highrate=rs.getString(5);
				location=rs.getString(6);
			}
			
			 String cDay = (String) session.getAttribute("sessionDay");
		
			  String cMonth = (String) session.getAttribute("sessionMonth");
			 
			  String cYear = (String) session.getAttribute("sessionYear");
			
			  String cDate = cYear+"-"+cMonth+"-"+cDay;
			  String sDate = cMonth+"/"+cDay+"/"+cYear;
			 
			  String stmt0="delete from schedules where email='"+(String)session.getAttribute("sessionMail")+"' and date < '" + (String)session.getAttribute("sessionCurrentDate") + "' and frequency like 'one time'";
				executeStmt(con, stmt0);
				 ConfigLogUtil.log(ConfigConstants.LOGFILE, stmt0);
			//let login member knows his events.	
			String stmt1 = "select distinct person.Id, Location from event, person, ppmembers where event.Id=person.Id and event.Status != 'done' and event.Status != 'cancel' and ppmembers.Email=person.Email and ppmembers.State="+"'"+state+"' "+ "and Time > '"+cDate+"'";
			ConfigLogUtil.log(ConfigConstants.LOGFILE, stmt1);
			ResultSet rs1 = executeQueryStmt(con, stmt1);
			String stmt2 = "select Username, Lowrate, Highrate, date, day, time, frequency from ppmembers, schedules where ppmembers.Email=schedules.email and schedules.club="+"'"+location+"'";
			ConfigLogUtil.log(ConfigConstants.LOGFILE, stmt2);
			ResultSet rs2 = executeQueryStmt(con, stmt2);
			//con.close();
			session.setAttribute("tempcon", con);
			session.setAttribute("result", rs1);
			session.setAttribute("schedule", rs2);
			session.setAttribute("sessionLocation", location);
			
			session.setAttribute("sessionState", state);
			session.setAttribute("sessionName", username);
			session.setAttribute("sessionNation", nation);
			session.setAttribute("sessionLow", lowrate);
			session.setAttribute("sessionHigh", highrate);
			ConfigLogUtil.log(ConfigConstants.LOGFILE, state+" "+nation);
			request.getRequestDispatcher("logintasks.jsp").forward(request, response);
			//request.getRequestDispatcher("setrequirementinfo.jsp").forward(request, response);
		}else{
			//session.setAttribute("pwd", "no");
			pwdValid=-1;
			request.getRequestDispatcher("partner.jsp").forward(request, response);
			//request.getRequestDispatcher("status.jsp").forward(request, response);
			//select Username, Status from events a, ppmembers b where a.Email=b.Email and a.Id=30387114987898;
		}
		
		// ("pwd", pwd);
		//request.getRequestDispatcher("test.jsp").forward(request, response);
		//con.close();
	}catch(Exception e){
		ConfigLogUtil.log(ConfigConstants.LOGFILE, "got exceptions in getConnection");
		e.printStackTrace();
	}
	
	//Dealing with the result set to check the password.
}
 

private void doLogin(HttpServletRequest request, HttpServletResponse response){
	
	//
	ConfigLogUtil.log(ConfigConstants.LOGFILE, "I am in doLogin");
	Connection con = getConnectTionFromPool();
	ConfigLogUtil.log(ConfigConstants.LOGFILE, "I passed getConnection.");
	//String stmt = "select Pwd from login where Email='mymtl@yahoo.com'";
	String stmt=null;
	String pwd="";
	try{
		String loginName = (String)request.getParameter("user");
		String loginPwd = (String)request.getParameter("pwd");
		stmt = "select Pwd from login where Email="+"'"+loginName+"'";
		ResultSet rs = executeQueryStmt(con, stmt);
		while (rs.next())
			pwd = rs.getString(1);
		
	
		
		con.close();
		
		if (pwd!=null && pwd!="" && pwd.equals(loginPwd) ){
			//session.setAttribute("pwd", "yes");
			pwdValid=1;
			session.setAttribute("sessionMail", loginName);
			session.setAttribute("sessionPwd", loginPwd);
			con = getConnectTionFromPool();
			stmt = "select Username, State, Country, Lowrate, Highrate, Locations  from ppmembers where Email="+"'"+loginName+"'";
			rs = executeQueryStmt(con, stmt);
			String username="";
			String state="";
			String nation="";
			String lowrate="";
			String highrate="";
			String location="";
			while (rs.next()){
				username = rs.getString(1);
				state=rs.getString(2);
				nation=rs.getString(3);
				lowrate=rs.getString(4);
				highrate=rs.getString(5);
				location=rs.getString(6);
			}
			
			 String cDay = (String) request.getParameter("currentDay");
			 session.setAttribute("sessionDay", cDay);
			  String cMonth = (String) request.getParameter("currentMonth");
			  session.setAttribute("sessionMonth", cMonth);
			  String cYear = (String) request.getParameter("currentYear");
			  session.setAttribute("sessionYear", cYear);
			  String cDate = cYear+"-"+cMonth+"-"+cDay;
			  String sDate = cMonth+"/"+cDay+"/"+cYear;
			  session.setAttribute("sessionCurrentDate", sDate);
			  String stmt0="delete from schedules where email='"+(String)session.getAttribute("sessionMail")+"' and date < '" + (String)session.getAttribute("sessionCurrentDate") + "' and frequency like 'one time'";
				executeStmt(con, stmt0);
				 ConfigLogUtil.log(ConfigConstants.LOGFILE, stmt0);
			//let login member knows his events.	
			String stmt1 = "select distinct person.Id, Location from event, person, ppmembers where event.Id=person.Id and event.Status != 'done' and event.Status != 'cancel' and ppmembers.Email=person.Email and ppmembers.Email="+"'"+loginName+"' "+ "and Time > '"+cDate+"'";
			ConfigLogUtil.log(ConfigConstants.LOGFILE, stmt1);
			ResultSet rs1 = executeQueryStmt(con, stmt1);
			String stmt2 = "select Username, Lowrate, Highrate, date, day, time, frequency from ppmembers, schedules where ppmembers.Email=schedules.email and schedules.club="+"'"+location+"'";
			ConfigLogUtil.log(ConfigConstants.LOGFILE, stmt2);
			ResultSet rs2 = executeQueryStmt(con, stmt2);
			//con.close();
			session.setAttribute("tempcon", con);
			session.setAttribute("result", rs1);
			session.setAttribute("schedule", rs2);
			session.setAttribute("sessionLocation", location);
			
			session.setAttribute("sessionState", state);
			session.setAttribute("sessionName", username);
			session.setAttribute("sessionNation", nation);
			session.setAttribute("sessionLow", lowrate);
			session.setAttribute("sessionHigh", highrate);
			ConfigLogUtil.log(ConfigConstants.LOGFILE, state+" "+nation);
			request.getRequestDispatcher("logintasks.jsp").forward(request, response);
			//request.getRequestDispatcher("setrequirementinfo.jsp").forward(request, response);
		}else{
			//session.setAttribute("pwd", "no");
			pwdValid=-1;
			request.getRequestDispatcher("partner.jsp").forward(request, response);
			//request.getRequestDispatcher("status.jsp").forward(request, response);
			//select Username, Status from events a, ppmembers b where a.Email=b.Email and a.Id=30387114987898;
		}
		
		// ("pwd", pwd);
		//request.getRequestDispatcher("test.jsp").forward(request, response);
		//con.close();
	}catch(Exception e){
		ConfigLogUtil.log(ConfigConstants.LOGFILE, "got exceptions in getConnection");
		e.printStackTrace();
	}
	
	//Dealing with the result set to check the password.
}

private void doSchedule(HttpServletRequest request, HttpServletResponse response){
	
	//
	ConfigLogUtil.log(ConfigConstants.LOGFILE, "I am in doSchedule");
	Connection con = getConnectTionFromPool();
	ConfigLogUtil.log(ConfigConstants.LOGFILE, "I passed getConnection.");
	
	String stmt=null;
	String stmt0=null;
	
	try{
		String date = (String)request.getParameter("testinput");
		String day = " ";
		String time = (String)request.getParameter("Time1");
		String country = (String)request.getParameter("country");
		String state = (String)request.getParameter("state");
		String club = (String)request.getParameter("club");
		String schedule = (String)request.getParameter("schedule");
		String email = (String)session.getAttribute("sessionMail");
		String lowrate = (String)session.getAttribute("sessionLow");
		String highrate = (String)session.getAttribute("sessionHigh");
		
		if (schedule.equals("one time")){
			
			day=" ";
			
		}
		if (schedule.equals("weekly")){
			stmt0="delete from schedules where email='"+(String)session.getAttribute("sessionMail")+"' and frequency='weekly'";
			executeStmt(con, stmt0);
			date=" ";
			if ((String)request.getParameter("mon")!=null)
				day=day + " mon,";
			if ((String)request.getParameter("tue")!=null)
				day=day + " tue,";
			if ((String)request.getParameter("wed")!=null)
				day=day + " wed,";
			if ((String)request.getParameter("thu")!=null)
				day=day + " thu,";
			if ((String)request.getParameter("fri")!=null)
				day=day + " fri,";
			if ((String)request.getParameter("sat")!=null)
				day=day + " sat,";
			if ((String)request.getParameter("sun")!=null)
				day=day + " sun,";
			
		}
		if (schedule.equals("daily")){
			stmt0="delete from schedules where email='"+(String)session.getAttribute("sessionMail")+"' and frequency='daily'";
			executeStmt(con, stmt0);
			day=" ";
			date=" ";
			
		}
		stmt = "insert into schedules values ("+"'"+email+"', "+"'"+date+"', "+"'"+day+"', "+"'"+time+"', "+"'"+schedule+"', "+"'"+club+"', "+"'"+state+"', "+"'"+country+"'"+")";
		ConfigLogUtil.log(ConfigConstants.LOGFILE, stmt0);
		ConfigLogUtil.log(ConfigConstants.LOGFILE, stmt);
		executeStmt(con, stmt);
		
		
	
		
		con.close();
		
		String message = "Your schedule has been posted.";
		  request.setAttribute("ConfirmMessage", message);
		request.getRequestDispatcher("confirm.jsp").forward(request, response);
		
	}catch(Exception e){
		ConfigLogUtil.log(ConfigConstants.LOGFILE, "got exceptions in doschedule");
		e.printStackTrace();
	}
	
	//Dealing with the result set to check the password.
}

private void doFindPwd(HttpServletRequest request, HttpServletResponse response){
	
	//
	ConfigLogUtil.log(ConfigConstants.LOGFILE, "I am in dofindpwd");
	Connection con = getConnectTionFromPool();
	ConfigLogUtil.log(ConfigConstants.LOGFILE, "I passed getConnection.");
	//String stmt = "select Pwd from login where Email='mymtl@yahoo.com'";
	String stmt=null;
	String pwd="";
	try{
		String loginName = (String)request.getParameter("user");
		
		stmt = "select Pwd from login where Email="+"'"+loginName+"'";
		ResultSet rs = executeQueryStmt(con, stmt);
		while (rs.next())
			pwd = rs.getString(1);
		
	
		
		con.close();
		
		if (pwd!=null && pwd!="" ){
			sendMail("This is the password:"+pwd, loginName, "password found.");
			 String message1 = "Your password has been sent to the email address entered..";
			  request.setAttribute("ConfirmMessage", message1);
			request.getRequestDispatcher("pwdfound.html").forward(request, response);
		}else{
			 String message2 = "The email address you entered does not exist. Please try again.";
			  request.setAttribute("ConfirmMessage", message2);
			request.getRequestDispatcher("pwd.jsp").forward(request, response);
			//request.getRequestDispatcher("status.jsp").forward(request, response);
			//select Username, Status from events a, ppmembers b where a.Email=b.Email and a.Id=30387114987898;
		}
		
		// ("pwd", pwd);
		//request.getRequestDispatcher("test.jsp").forward(request, response);
		//con.close();
	}catch(Exception e){
		ConfigLogUtil.log(ConfigConstants.LOGFILE, "got exceptions in getConnection");
		e.printStackTrace();
	}
	
	//Dealing with the result set to check the password.
}


private Connection getConnectTionFromPool(){
	
	String dbURL= "java:comp/env/jdbc/staging";
	try {
		InitialContext ic = new InitialContext();
		DataSource ds=(DataSource) ic.lookup(dbURL);
		Connection myConn = ds.getConnection();
		return myConn;
	}catch (Exception e){
		ConfigLogUtil.log(ConfigConstants.LOGFILE, "got exceptions in getConnection from JNDI");
		ConfigLogUtil.log(ConfigConstants.LOGFILE, e.getMessage());
		return null;
	}
		
		//myConn.close();
	
	
}

private ResultSet executeQueryStmt(Connection con, String query) {
	
	
	ConfigLogUtil.log(ConfigConstants.LOGFILE, "in executeQueryStmt");
	
		try {
	
		    Statement stmt = con.createStatement();
		
		     ResultSet rs = stmt.executeQuery(query);
		     
		    // con.close();
		     
		     ConfigLogUtil.log(ConfigConstants.LOGFILE, "rs is returned");
		     test = true;
		     
		     return rs;
		
		    
		}
		catch (SQLException e) {
			ConfigLogUtil.log(ConfigConstants.LOGFILE, "in SQLException");
		     e.printStackTrace();
		     test = false;
		 }
		 catch (Exception e) {
			 ConfigLogUtil.log(ConfigConstants.LOGFILE, "in Exception");
		     e.printStackTrace();
		     test = false;
		 }
		
	
		return null;

}

private boolean executeStmt(Connection con, String statement) {
	
	
	ConfigLogUtil.log(ConfigConstants.LOGFILE, "in executeStmt");
	
		try {
	
		    Statement stmt = con.createStatement();
		
		     boolean flag=stmt.execute(statement);
		     
		    // con.close();
		     
		     ConfigLogUtil.log(ConfigConstants.LOGFILE, "flag is returned");
		     test = true;
		     
		     return true;
		
		    
		}
		catch (SQLException e) {
			
			ConfigLogUtil.log(ConfigConstants.LOGFILE, "in SQLException");
		     e.printStackTrace();
		     test = false;
		     return false;
		 }
		 catch (Exception e) {
			 ConfigLogUtil.log(ConfigConstants.LOGFILE, "in Exception");
		     e.printStackTrace();
		     test = false;
		 }
		
	
		return false;

}

private void sendMail(String Text, String s, String event){
	String to = s;
	String from = "tt00pingpong@gmail.com";
	String host = "smtp.gmail.com";
	boolean debug = Boolean.valueOf("true").booleanValue();

	// create some properties and get the default Session
	Properties props = new Properties();
	props.put("mail.smtp.user", "tt00pingpong@gmail.com");
	props.put("mail.smtp.host", host);
	props.put("mail.smtp.port", "465");
	props.put("mail.smtp.auth", true);
	props.put("mail.smtp.starttls.enable", "true");
	
	props.put("mail.smtp.socketFactory.port", "465");

	 
	props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");
	
	props.put("mail.smtp.socketFactory.fallback", "false");
	if (debug) props.put("mail.debug", "true");

	Session session = Session.getInstance(props, null);
	session.setDebug(debug);
	
	try {
	    // create a message
	    MimeMessage msg = new MimeMessage(session);
	    msg.setFrom(new InternetAddress(from));
	    
	    
	    InternetAddress[] address = {new InternetAddress(to)};
	   
	    msg.setRecipients(Message.RecipientType.TO, address);
	    msg.setSubject("PingPongMatch Invitation"+" "+event);
	    msg.setSentDate(new Date());
	    // If the desired charset is known, you can use
	    // setText(text, charset)
	    msg.setText(Text);
	    Transport t = session.getTransport("smtp");
	    t.connect(host, "tt00pingpong@gmail.com", "yongmei_m");
	    msg.saveChanges();      // don't forget this
	    t.sendMessage(msg, msg.getAllRecipients());
	    t.close();

	    

	    
	    //Transport.send(msg);
	} catch (Exception mex) {
		emailError = "Yes";
	    //System.out.println("\n--Exception handling in msgsendsample.java");
		ConfigLogUtil.log(ConfigConstants.LOGFILE, "\n--Exception handling in msgsendsample.java");
	    mex.printStackTrace();
	   // System.out.println();
	    Exception ex = mex;
	    do {
		if (ex instanceof SendFailedException) {
		    SendFailedException sfex = (SendFailedException)ex;
		    Address[] invalid = sfex.getInvalidAddresses();
		    if (invalid != null) {
			//System.out.println("    ** Invalid Addresses");
		    	ConfigLogUtil.log(ConfigConstants.LOGFILE, "    ** Invalid Addresses");	
			if (invalid != null) {
			    for (int i = 0; i < invalid.length; i++) 
				//System.out.println("         " + invalid[i]);
			    	ConfigLogUtil.log(ConfigConstants.LOGFILE, " "+invalid[i]);		
			}
		    }
		    Address[] validUnsent = sfex.getValidUnsentAddresses();
		    if (validUnsent != null) {
			//System.out.println("    ** ValidUnsent Addresses");
			ConfigLogUtil.log(ConfigConstants.LOGFILE, "ValidUnsent Address");
			if (validUnsent != null) {
			    for (int i = 0; i < validUnsent.length; i++) 
				//System.out.println("         "+validUnsent[i]);
			    ConfigLogUtil.log(ConfigConstants.LOGFILE, " "+validUnsent[i]);
			}
		    }
		    Address[] validSent = sfex.getValidSentAddresses();
		    if (validSent != null) {
			//System.out.println("    ** ValidSent Addresses");
		    	ConfigLogUtil.log(ConfigConstants.LOGFILE, "ValidSent Addresses");
			if (validSent != null) {
			    for (int i = 0; i < validSent.length; i++) 
				//System.out.println("         "+validSent[i]);
			    	ConfigLogUtil.log(ConfigConstants.LOGFILE, " "+validSent[i]);
			}
		    }
		}
		//System.out.println();
		if (ex instanceof MessagingException)
		    ex = ((MessagingException)ex).getNextException();
		else
		    ex = null;
	    } while (ex != null);
	}
	
	
	
	
}



}

